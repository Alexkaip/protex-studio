const STORAGE_KEY = "protex_admin_products_v3";
const SETTINGS_KEY = "protex_admin_settings_v3";

let adminProducts = [];
let settings = {
  firmName: "Protex-austria GmbH",
  firmEmail: "office@protex-austria.at",
  firmLogo: ""
};

document.addEventListener("DOMContentLoaded", () => {
  loadData();
  bindAdminEvents();
  updateAdminList();
  updateLogoPreview();
});

function bindAdminEvents() {
  document.getElementById("save-product-btn").addEventListener("click", addProduct);
  document.getElementById("delete-all-btn").addEventListener("click", deleteAllProducts);
  document.getElementById("export-btn").addEventListener("click", exportKundenKonfigurator);

  document.getElementById("firm-name").addEventListener("input", saveSettingsFromForm);
  document.getElementById("firm-email").addEventListener("input", saveSettingsFromForm);
  document.getElementById("firm-logo").addEventListener("change", handleLogoUpload);
  document.getElementById("delete-logo-btn").addEventListener("click", () => {
    settings.firmLogo = "";
    saveSettings();
    updateLogoPreview();
  });
}

function loadData() {
  try {
    adminProducts = JSON.parse(localStorage.getItem(STORAGE_KEY) || "[]");
  } catch {
    adminProducts = [];
  }

  try {
    const savedSettings = JSON.parse(localStorage.getItem(SETTINGS_KEY) || "{}");
    settings = { ...settings, ...savedSettings };
  } catch {}

  document.getElementById("firm-name").value = settings.firmName || "";
  document.getElementById("firm-email").value = settings.firmEmail || "";
}

function saveProducts() {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(adminProducts));
}

function saveSettings() {
  localStorage.setItem(SETTINGS_KEY, JSON.stringify(settings));
}

function saveSettingsFromForm() {
  settings.firmName = document.getElementById("firm-name").value.trim();
  settings.firmEmail = document.getElementById("firm-email").value.trim();
  saveSettings();
}

function fileToDataUrl(file) {
  return new Promise((resolve, reject) => {
    if (!file || !file.type.startsWith("image/")) {
      reject(new Error("Bitte eine Bilddatei auswählen."));
      return;
    }

    const reader = new FileReader();
    reader.onload = () => resolve(reader.result);
    reader.onerror = () => reject(new Error("Bild konnte nicht gelesen werden."));
    reader.readAsDataURL(file);
  });
}

async function handleLogoUpload(event) {
  const file = event.target.files[0];
  if (!file) return;

  try {
    settings.firmLogo = await fileToDataUrl(file);
    saveSettingsFromForm();
    saveSettings();
    updateLogoPreview();
  } catch (err) {
    alert(err.message);
  }
}

function updateLogoPreview() {
  const wrap = document.getElementById("logo-preview-wrap");
  const img = document.getElementById("logo-preview");

  if (settings.firmLogo) {
    img.src = settings.firmLogo;
    wrap.hidden = false;
  } else {
    img.removeAttribute("src");
    wrap.hidden = true;
  }
}

async function addProduct() {
  const fileInput = document.getElementById("admin-product-img");
  const titleInput = document.getElementById("admin-title");
  const descInput = document.getElementById("admin-desc");
  const priceInput = document.getElementById("admin-price");

  const file = fileInput.files[0];
  const title = titleInput.value.trim();
  const desc = descInput.value.trim();
  const price = priceInput.value.trim();

  if (!file || !title || !price) {
    alert("Bitte Produktbild, Produktname und Preis ausfüllen.");
    return;
  }

  try {
    const img = await fileToDataUrl(file);

    adminProducts.push({
      id: crypto.randomUUID ? crypto.randomUUID() : String(Date.now()),
      title,
      desc,
      price,
      img
    });

    saveProducts();
    updateAdminList();

    fileInput.value = "";
    titleInput.value = "";
    descInput.value = "";
    priceInput.value = "";
  } catch (err) {
    alert(err.message);
  }
}

function removeProduct(index) {
  adminProducts.splice(index, 1);
  saveProducts();
  updateAdminList();
}

function deleteAllProducts() {
  if (!adminProducts.length) return;
  if (!confirm("Wirklich alle Produkte löschen?")) return;

  adminProducts = [];
  saveProducts();
  updateAdminList();
}

function updateAdminList() {
  const list = document.getElementById("admin-prod-list");
  const count = document.getElementById("prod-count");
  count.textContent = String(adminProducts.length);
  list.innerHTML = "";

  if (!adminProducts.length) {
    const empty = document.createElement("div");
    empty.className = "empty";
    empty.textContent = "Noch keine Produkte hinzugefügt.";
    list.appendChild(empty);
    return;
  }

  adminProducts.forEach((p, index) => {
    const item = document.createElement("div");
    item.className = "product-item";

    const img = document.createElement("img");
    img.className = "product-thumb";
    img.src = p.img;
    img.alt = p.title;

    const info = document.createElement("div");

    const title = document.createElement("div");
    title.className = "product-title";
    title.textContent = p.title;

    const meta = document.createElement("div");
    meta.className = "product-meta";
    meta.textContent = `€ ${formatPrice(p.price)}${p.desc ? " · " + p.desc : ""}`;

    info.appendChild(title);
    info.appendChild(meta);

    const btn = document.createElement("button");
    btn.className = "delete-btn";
    btn.type = "button";
    btn.textContent = "Löschen";
    btn.addEventListener("click", () => removeProduct(index));

    item.appendChild(img);
    item.appendChild(info);
    item.appendChild(btn);
    list.appendChild(item);
  });
}

function formatPrice(value) {
  const num = Number(String(value).replace(",", "."));
  return Number.isFinite(num) ? num.toFixed(2) : "0.00";
}

function htmlEscape(str) {
  return String(str ?? "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

function jsString(value) {
  return JSON.stringify(value).replaceAll("</script", "<\\/script");
}

function exportKundenKonfigurator() {
  saveSettingsFromForm();

  if (!settings.firmEmail) {
    alert("Bitte E-Mail-Adresse eintragen.");
    return;
  }

  if (!adminProducts.length) {
    alert("Bitte zuerst mindestens ein Produkt speichern.");
    return;
  }

  const exportProducts = adminProducts.filter(p => p.img && p.img.startsWith("data:image/"));

  if (!exportProducts.length) {
    alert("Es wurden keine gültigen Produktbilder gefunden. Bitte Produkte neu mit Bild speichern.");
    return;
  }

  const kundenHtml = buildCustomerHtml({
    firmName: settings.firmName || "Produkt-Konfigurator",
    firmEmail: settings.firmEmail,
    firmLogo: settings.firmLogo || "",
    products: exportProducts
  });

  const blob = new Blob([kundenHtml], { type: "text/html;charset=utf-8" });
  const url = URL.createObjectURL(blob);

  const a = document.createElement("a");
  a.href = url;
  a.download = "kunden_konfigurator.html";
  document.body.appendChild(a);
  a.click();
  a.remove();

  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

function buildCustomerHtml(data) {
  return `<!DOCTYPE html>
<html lang="de">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>${htmlEscape(data.firmName)} - Kunden-Konfigurator</title>
<style>
:root{--primary:#2563eb;--primary-hover:#1d4ed8;--secondary:#64748b;--bg:#f8fafc;--surface:#fff;--text:#0f172a;--muted:#64748b;--border:#dbe3ee}
*{box-sizing:border-box}
body{margin:0;font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Arial,sans-serif;background:var(--bg);color:var(--text);padding:8px}
.header-bar{max-width:1280px;margin:0 auto 16px;background:var(--surface);border:1px solid var(--border);border-radius:16px;padding:18px 22px;display:flex;align-items:center;justify-content:space-between;gap:18px;box-shadow:0 8px 22px rgba(15,23,42,.05)}
.header-logo img{max-height:80px;max-width:260px;object-fit:contain;display:block}
.logo-placeholder{font-weight:900;font-size:1.4rem}
.header-contact{text-align:right;color:#475569;line-height:1.5}
.header-contact strong{color:#0f172a}
.header-contact a{color:var(--primary);font-weight:800;text-decoration:none}
.container{max-width:1280px;margin:0 auto;display:grid;grid-template-columns:1fr 390px;gap:16px}
.card{background:var(--surface);border:1px solid var(--border);border-radius:16px;padding:16px;box-shadow:0 8px 22px rgba(15,23,42,.04)}
.editor-section{background:#eef2f7;border:2px dashed #cbd5e1;min-height:620px;display:flex;align-items:center;justify-content:center;position:relative;overflow:hidden}
#canvas-container{width:100%;height:100%;min-height:580px;display:flex;align-items:center;justify-content:center;position:relative}
#product-img{max-width:96%;max-height:560px;width:auto;height:auto;object-fit:contain;display:block;background:#fff;border-radius:12px}
#overlay-element{position:absolute;left:30%;top:30%;z-index:20;cursor:move;touch-action:none;user-select:none;border:1px dashed transparent;padding:8px}
#overlay-element.active,#overlay-element:hover{border-color:var(--primary);background:rgba(37,99,235,.06)}
#overlay-img{width:140px;height:auto;display:none;pointer-events:none}
#overlay-text{font-size:28px;font-weight:900;white-space:nowrap;display:none;pointer-events:none;color:#000}
.resizer{width:20px;height:20px;position:absolute;right:-10px;bottom:-10px;border-radius:50%;background:var(--primary);border:3px solid #fff;box-shadow:0 2px 8px rgba(0,0,0,.25);cursor:se-resize;display:none}
#overlay-element.active .resizer,#overlay-element:hover .resizer{display:block}
h2{font-size:1.2rem;margin:6px 0 14px;padding-bottom:9px;border-bottom:2px solid #e2e8f0}
.form-group{margin-bottom:13px}
label{display:block;font-size:.9rem;font-weight:800;margin-bottom:6px;color:#334155}
input[type=text],input[type=email],textarea{width:100%;padding:11px 12px;border:1px solid var(--border);border-radius:10px;font-size:1rem;outline:none}
input[type=file]{width:100%;border:1px dashed #e2e8f0;background:#f8fafc;border-radius:10px;padding:11px}
.btn{width:100%;border:none;border-radius:10px;background:var(--primary);color:#fff;padding:13px 16px;font-weight:900;font-size:1rem;cursor:pointer}
.btn:hover{background:var(--primary-hover)}
.btn-secondary{background:var(--secondary)}
.btn-light{background:#e2e8f0;color:#0f172a}
.btn-light:hover{background:#cbd5e1}
.request-list{background:#f8fafc;border:1px solid var(--border);border-radius:10px;padding:10px;margin:12px 0}
.request-item{display:flex;justify-content:space-between;gap:8px;padding:8px;border-bottom:1px solid #e2e8f0;font-size:.9rem}
.request-item:last-child{border-bottom:none}
.remove-request{border:none;background:transparent;color:#dc2626;font-weight:900;cursor:pointer}
select{width:100%;padding:11px 12px;border:1px solid var(--border);border-radius:10px;font-size:1rem;background:#fff}
.custom-dropdown{position:relative;margin-bottom:12px}
.dropdown-selected{background:#fff;border:1px solid var(--border);border-radius:10px;padding:12px;cursor:pointer;display:flex;align-items:center;justify-content:space-between;font-weight:800}
.dropdown-selected:after{content:"▼";font-size:.75rem;color:#64748b;margin-left:8px}
.dropdown-options{display:none;position:absolute;left:0;right:0;top:calc(100% + 5px);background:#fff;border:1px solid var(--border);border-radius:10px;box-shadow:0 18px 30px rgba(15,23,42,.15);z-index:100;max-height:280px;overflow:auto}
.custom-dropdown.open .dropdown-options{display:block}
.dropdown-option{display:flex;align-items:center;gap:12px;padding:10px 12px;cursor:pointer;border-bottom:1px solid #f1f5f9}
.dropdown-option:hover,.dropdown-option.active{background:#eff6ff}
.dropdown-thumb{width:46px;height:46px;object-fit:contain;background:#f8fafc;border:1px solid #e2e8f0;border-radius:8px}
.dropdown-title{font-weight:800}
.dropdown-price{font-size:.85rem;color:#16a34a;font-weight:900}
.product-info-box{background:#f8fafc;border:1px solid var(--border);border-radius:10px;padding:12px;margin-bottom:16px}
#curr-title{font-weight:900;margin-bottom:4px}
#curr-desc{font-size:.9rem;color:var(--muted)}
.price-tag{color:#16a34a;font-weight:900;margin-top:6px}
.tabs{display:flex;border-bottom:1px solid var(--border);margin-bottom:14px}
.tab{flex:1;text-align:center;padding:11px;cursor:pointer;color:#64748b;font-weight:900;border-bottom:3px solid transparent}
.tab.active{color:var(--primary);border-color:var(--primary)}
.tab-content{display:none}
.tab-content.active{display:block}
.hint{font-size:.82rem;color:var(--muted);text-align:center;margin:12px 0}
@media(max-width:900px){.container{grid-template-columns:1fr}.header-bar{flex-direction:column;text-align:center}.header-contact{text-align:center}.editor-section{min-height:430px}#canvas-container{min-height:400px}#product-img{max-height:390px}}
</style>
</head>
<body>
<form name="design-anfrage" netlify netlify-honeypot="bot-field" enctype="multipart/form-data" hidden>
  <input type="hidden" name="form-name" value="design-anfrage">
  <input type="text" name="bot-field">
  <input type="email" name="kunde_email">
  <textarea name="nachricht"></textarea>
  <input type="file" name="layout_1">
  <input type="file" name="layout_2">
  <input type="file" name="layout_3">
  <input type="file" name="layout_4">
  <input type="file" name="layout_5">
</form>
<header class="header-bar">
  <div class="header-logo">${data.firmLogo ? `<img src="${data.firmLogo}" alt="Firmenlogo">` : `<div class="logo-placeholder">${htmlEscape(data.firmName)}</div>`}</div>
  <div class="header-contact">
    <strong>${htmlEscape(data.firmName)}</strong><br>
    ✉️ <a href="mailto:${htmlEscape(data.firmEmail)}">${htmlEscape(data.firmEmail)}</a>
  </div>
</header>

<main class="container">
  <section class="card editor-section">
    <div id="canvas-container">
      <img id="product-img" alt="Produktbild">
      <div id="overlay-element">
        <img id="overlay-img" alt="Design">
        <span id="overlay-text">Dein Text</span>
        <div class="resizer" id="resizer"></div>
      </div>
    </div>
  </section>

  <aside class="sidebar">
    <div class="card">
      <h2>1. Produkt wählen</h2>
      <div class="custom-dropdown" id="product-dropdown">
        <div class="dropdown-selected" id="dropdown-trigger">Produkt auswählen...</div>
        <div class="dropdown-options" id="dropdown-options-container"></div>
      </div>

      <div class="product-info-box">
        <div id="curr-title">Kein Produkt</div>
        <div id="curr-desc">Bitte wählen Sie ein Produkt aus.</div>
        <div id="curr-price" class="price-tag"></div>
      </div>

      <h2>2. Design hinzufügen</h2>
      <div class="tabs">
        <div class="tab active" data-tab="logo">Logo Upload</div>
        <div class="tab" data-tab="text">Text einfügen</div>
      </div>

      <div id="tab-logo" class="tab-content active">
        <div class="form-group">
          <label for="logo-loader">Eigenes Logo hochladen (PNG/JPG)</label>
          <input type="file" id="logo-loader" accept="image/*">
        </div>
      </div>

      <div id="tab-text" class="tab-content">
        <div class="form-group">
          <label for="text-input">Dein Text</label>
          <input type="text" id="text-input" placeholder="Hier schreiben...">
        </div>
        <div class="form-group">
          <label for="text-color">Textfarbe</label>
          <input type="color" id="text-color" value="#000000">
        </div>
        <div class="form-group">
          <label for="font-select">Schriftart</label>
          <select id="font-select">
            <option value="Arial, sans-serif">Arial</option>
            <option value="'Arial Black', Arial, sans-serif">Arial Black</option>
            <option value="'Trebuchet MS', sans-serif">Trebuchet</option>
            <option value="'Verdana', sans-serif">Verdana</option>
            <option value="'Georgia', serif">Georgia</option>
            <option value="'Times New Roman', serif">Times New Roman</option>
            <option value="'Courier New', monospace">Courier New</option>
            <option value="'Comic Sans MS', cursive">Comic Sans</option>
            <option value="'Impact', sans-serif">Impact</option>
            <option value="'Brush Script MT', cursive">Brush Script</option>
          </select>
        </div>
      </div>

      <button class="btn btn-secondary" id="reset-design-btn" type="button">Design zurücksetzen</button>
      <div class="hint">💡 Logo/Text im Bild verschieben und unten rechts skalieren.</div>

      <h2>3. Produkte sammeln</h2>
      <button class="btn btn-light" id="add-request-btn" type="button">Aktuelles Produkt zur Anfrage hinzufügen</button>
      <div class="request-list" id="request-list">
        <div class="hint">Noch keine Produkte in der Anfrage.</div>
      </div>
      <button class="btn btn-secondary" id="download-design-btn" type="button">Alle gespeicherten Layouts herunterladen</button>
      <div class="hint" style="background:#fff7ed;border:1px solid #fed7aa;border-radius:10px;padding:10px;color:#9a3412;">
        Optional: Du kannst die Layouts zusätzlich herunterladen. Für die Online-Anfrage werden die gespeicherten Layouts automatisch mitgesendet.
      </div>

      <h2>4. Anfrage senden</h2>
      <div class="form-group">
        <label for="client-email">Deine E-Mail-Adresse</label>
        <input type="email" id="client-email" placeholder="name@beispiel.at">
      </div>
      <div class="form-group">
        <label for="client-notes">Anmerkungen / Stückzahl</label>
        <textarea id="client-notes" rows="3" placeholder="z.B. 20 Stück..."></textarea>
      </div>
      <button class="btn" id="send-order-btn" type="button">Anfrage direkt senden</button>
      <div id="send-status" class="hint"></div>
      <div class="hint">Hinweis: Online über Netlify werden Anfrage und Layoutbilder direkt gesendet. Lokal am PC funktioniert der Direktversand noch nicht.</div>
      <div id="mail-fallback" style="display:none;margin-top:12px;background:#f8fafc;border:1px solid #dbe3ee;border-radius:10px;padding:12px;">
        <strong>Falls die Mail leer geöffnet wurde:</strong>
        <p style="font-size:.85rem;color:#64748b;margin:6px 0 8px;">Diesen Text kopieren und in die E-Mail einfügen:</p>
        <textarea id="mail-copy-text" rows="8" style="width:100%;border:1px solid #dbe3ee;border-radius:8px;padding:10px;font-family:inherit;"></textarea>
        <button class="btn btn-secondary" id="copy-mail-btn" type="button" style="margin-top:8px;">Text kopieren</button>
      </div>
    </div>
  </aside>
</main>

<script>
const products = ${jsString(data.products)};
const firmEmail = ${jsString(data.firmEmail)};
let currentProductIndex = 0;
let mode = "logo";
let requestItems = [];
let overlayLeft = 30;
let overlayTop = 30;

const pImg = document.getElementById("product-img");
const cTitle = document.getElementById("curr-title");
const cDesc = document.getElementById("curr-desc");
const cPrice = document.getElementById("curr-price");
const overlay = document.getElementById("overlay-element");
const overlayImg = document.getElementById("overlay-img");
const overlayText = document.getElementById("overlay-text");
const dropdown = document.getElementById("product-dropdown");
const dropdownTrigger = document.getElementById("dropdown-trigger");
const optionsContainer = document.getElementById("dropdown-options-container");
const canvas = document.getElementById("canvas-container");

document.addEventListener("DOMContentLoaded", init);

function init(){
  buildDropdown();
  if(products.length) selectProduct(0);
  bindEvents();
  setupDragAndResize();
  resetOverlay();
}

function bindEvents(){
  dropdownTrigger.addEventListener("click", (e)=>{dropdown.classList.toggle("open");e.stopPropagation();});
  window.addEventListener("click", ()=>dropdown.classList.remove("open"));
  document.querySelectorAll(".tab").forEach(tab => tab.addEventListener("click", () => switchTab(tab.dataset.tab)));
  document.getElementById("logo-loader").addEventListener("change", handleLogoUpload);
  document.getElementById("text-input").addEventListener("input", updateText);
  document.getElementById("text-color").addEventListener("input", updateText);
  document.getElementById("font-select").addEventListener("change", updateText);
  document.getElementById("reset-design-btn").addEventListener("click", resetDesign);
  document.getElementById("add-request-btn").addEventListener("click", addCurrentProductToRequest);
  document.getElementById("download-design-btn").addEventListener("click", downloadAllRequestDesignImages);
  document.getElementById("send-order-btn").addEventListener("click", sendOrder);
}

function buildDropdown(){
  optionsContainer.innerHTML = "";
  products.forEach((p, idx)=>{
    const opt = document.createElement("div");
    opt.className = "dropdown-option";
    opt.innerHTML = '<img class="dropdown-thumb" src="'+p.img+'" alt=""><div><div class="dropdown-title"></div><div class="dropdown-price">€ '+formatPrice(p.price)+'</div></div>';
    opt.querySelector(".dropdown-title").textContent = p.title;
    opt.addEventListener("click", (e)=>{selectProduct(idx);dropdown.classList.remove("open");e.stopPropagation();});
    optionsContainer.appendChild(opt);
  });
}

function selectProduct(index){
  if(!products[index]) return;
  currentProductIndex = index;
  const p = products[index];

  pImg.src = p.img;
  cTitle.textContent = p.title;
  cDesc.textContent = p.desc || "";
  cPrice.textContent = "€ " + formatPrice(p.price);

  dropdownTrigger.innerHTML = '<span style="display:flex;align-items:center;gap:8px;min-width:0;"><img src="'+p.img+'" style="width:26px;height:26px;object-fit:contain;border-radius:4px;background:#f8fafc;"> <span style="overflow:hidden;text-overflow:ellipsis;white-space:nowrap;"></span></span>';
  dropdownTrigger.querySelector("span span").textContent = p.title;

  document.querySelectorAll(".dropdown-option").forEach((opt, idx)=>opt.classList.toggle("active", idx === index));
  resetOverlay();
}

function switchTab(type){
  mode = type;
  document.querySelectorAll(".tab").forEach(t => t.classList.toggle("active", t.dataset.tab === type));
  document.querySelectorAll(".tab-content").forEach(c => c.classList.remove("active"));
  document.getElementById("tab-"+type).classList.add("active");

  if(type === "logo"){
    overlayImg.style.display = overlayImg.src ? "block" : "none";
    overlayText.style.display = "none";
  } else {
    overlayImg.style.display = "none";
    overlayText.style.display = "block";
    updateText();
  }
}

function handleLogoUpload(e){
  const file = e.target.files[0];
  if(!file || !file.type.startsWith("image/")) return;

  const reader = new FileReader();
  reader.onload = () => {
    overlayImg.src = reader.result;
    switchTab("logo");
  };
  reader.readAsDataURL(file);
}

function updateText(){
  overlayText.textContent = document.getElementById("text-input").value || "Dein Text";
  overlayText.style.color = document.getElementById("text-color").value;
  overlayText.style.fontFamily = document.getElementById("font-select").value;
}

function resetDesign(){
  overlayImg.removeAttribute("src");
  overlayImg.style.display = "none";
  document.getElementById("logo-loader").value = "";
  document.getElementById("text-input").value = "";
  document.getElementById("text-color").value = "#000000";
  document.getElementById("font-select").value = "Arial, sans-serif";
  updateText();
  switchTab(mode);
  resetOverlay();
}

function resetOverlay(){
  overlay.style.left = "30%";
  overlay.style.top = "30%";
  overlayImg.style.width = "140px";
  overlayText.style.fontSize = "28px";
}

function setupDragAndResize(){
  let action = null;
  let startX = 0, startY = 0, startLeft = 0, startTop = 0, startSize = 0;

  function point(e){ return e.touches ? e.touches[0] : e; }

  function down(e){
    const pt = point(e);
    action = e.target.id === "resizer" ? "resize" : "drag";
    startX = pt.clientX;
    startY = pt.clientY;
    startLeft = overlay.offsetLeft;
    startTop = overlay.offsetTop;
    startSize = mode === "logo" ? (overlayImg.offsetWidth || 140) : parseFloat(getComputedStyle(overlayText).fontSize);
    overlay.classList.add("active");
    e.preventDefault();
  }

  function move(e){
    if(!action) return;
    const pt = point(e);

    if(action === "drag"){
      let newLeft = startLeft + (pt.clientX - startX);
      let newTop = startTop + (pt.clientY - startY);

      const maxLeft = Math.max(0, canvas.clientWidth - overlay.offsetWidth);
      const maxTop = Math.max(0, canvas.clientHeight - overlay.offsetHeight);

      overlay.style.left = Math.max(0, Math.min(newLeft, maxLeft)) + "px";
      overlay.style.top = Math.max(0, Math.min(newTop, maxTop)) + "px";
    }

    if(action === "resize"){
      const diff = pt.clientX - startX;
      if(mode === "logo"){
        overlayImg.style.width = Math.max(35, startSize + diff) + "px";
      } else {
        overlayText.style.fontSize = Math.max(12, startSize + diff / 3) + "px";
      }
    }

    e.preventDefault();
  }

  function up(){
    action = null;
    overlay.classList.remove("active");
  }

  overlay.addEventListener("mousedown", down);
  overlay.addEventListener("touchstart", down, {passive:false});
  window.addEventListener("mousemove", move);
  window.addEventListener("touchmove", move, {passive:false});
  window.addEventListener("mouseup", up);
  window.addEventListener("touchend", up);
}

function getCurrentDesignDetails(){
  if(mode === "logo"){
    return "Typ: Eigenes Logo hochgeladen.\\nHinweis: Logo/Design-Bild bitte manuell als Anhang mitsenden.";
  }

  return "Typ: Textwunsch\\n" +
    "Inhalt: " + (document.getElementById("text-input").value || "Dein Text") + "\\n" +
    "Farbe: " + document.getElementById("text-color").value + "\\n" +
    "Schriftart: " + document.getElementById("font-select").options[document.getElementById("font-select").selectedIndex].text;
}

function addCurrentProductToRequest(){
  const prod = products[currentProductIndex];
  if(!prod){ alert("Bitte zuerst ein Produkt auswählen."); return; }

  const productRect = pImg.getBoundingClientRect();
  const overlayRect = overlay.getBoundingClientRect();

  const layout = {
    mode: mode,
    relX: productRect.width ? (overlayRect.left - productRect.left) / productRect.width : 0.3,
    relY: productRect.height ? (overlayRect.top - productRect.top) / productRect.height : 0.3,
    relW: productRect.width ? overlayRect.width / productRect.width : 0.2,
    text: document.getElementById("text-input").value || "Dein Text",
    color: document.getElementById("text-color").value,
    fontValue: document.getElementById("font-select").value,
    fontLabel: document.getElementById("font-select").options[document.getElementById("font-select").selectedIndex].text,
    fontSizePx: parseFloat(getComputedStyle(overlayText).fontSize) || 28,
    logoSrc: overlayImg.src || ""
  };

  requestItems.push({
    title: prod.title,
    price: prod.price,
    desc: prod.desc || "",
    productImg: prod.img,
    design: getCurrentDesignDetails(),
    layout: layout
  });

  renderRequestList();
  alert("Produkt/Layout wurde zur Anfrage hinzugefügt. Nicht vergessen: Am Ende Layouts herunterladen und an die E-Mail anhängen.");
}

function removeRequestItem(index){
  requestItems.splice(index, 1);
  renderRequestList();
}

function renderRequestList(){
  const list = document.getElementById("request-list");
  list.innerHTML = "";

  if(!requestItems.length){
    const empty = document.createElement("div");
    empty.className = "hint";
    empty.textContent = "Noch keine Produkte in der Anfrage.";
    list.appendChild(empty);
    return;
  }

  requestItems.forEach((item, idx) => {
    const row = document.createElement("div");
    row.className = "request-item";

    const info = document.createElement("div");
    info.innerHTML = "<strong></strong><br><span></span>";
    info.querySelector("strong").textContent = item.title;
    info.querySelector("span").textContent = "€ " + item.price + " · Layout gespeichert";

    const btn = document.createElement("button");
    btn.className = "remove-request";
    btn.type = "button";
    btn.textContent = "Entfernen";
    btn.addEventListener("click", () => removeRequestItem(idx));

    row.appendChild(info);
    row.appendChild(btn);
    list.appendChild(row);
  });
}

function buildMailText(){
  const clientEmail = document.getElementById("client-email").value.trim();
  const notes = document.getElementById("client-notes").value.trim();

  const items = requestItems.length ? requestItems : [{
    title: products[currentProductIndex].title,
    price: products[currentProductIndex].price,
    desc: products[currentProductIndex].desc || "",
    design: getCurrentDesignDetails()
  }];

  let productText = "";
  items.forEach((item, index) => {
    productText += (index + 1) + ". " + item.title + "\\n" +
      "- Basispreis: € " + item.price + "\\n" +
      "- Beschreibung: " + (item.desc || "-") + "\\n" +
      "- Design:\\n" + item.design + "\\n\\n";
  });

  return "Hallo!\\n\\n" +
    "ich habe folgende Produkte im Konfigurator zusammengestellt.\\n\\n" +
    "PRODUKTE / ANFRAGE:\\n" +
    productText +
    "KUNDEN-INFOS:\\n" +
    "- Meine E-Mail: " + clientEmail + "\\n" +
    "- Anmerkung / Stückzahl: " + (notes || "-") + "\\n\\n" +
    "Hinweis: Das Design-Bild/Logo wird falls vorhanden als Anhang manuell mitgesendet.\\n\\n" +
    "Bitte um Rückmeldung.\\n";
}

function createLayoutBlob(item){
  return new Promise((resolve, reject) => {
    const canvasExport = document.createElement("canvas");
    const ctx = canvasExport.getContext("2d");
    const productImage = new Image();

    productImage.onload = function(){
      const maxWidth = 1400;
      const originalW = productImage.naturalWidth || 1200;
      const originalH = productImage.naturalHeight || 900;
      const scale = Math.min(1, maxWidth / originalW);

      canvasExport.width = Math.round(originalW * scale);
      canvasExport.height = Math.round(originalH * scale);

      ctx.fillStyle = "#ffffff";
      ctx.fillRect(0, 0, canvasExport.width, canvasExport.height);
      ctx.drawImage(productImage, 0, 0, canvasExport.width, canvasExport.height);

      const layout = item.layout || {};
      const drawX = (layout.relX ?? 0.3) * canvasExport.width;
      const drawY = (layout.relY ?? 0.3) * canvasExport.height;
      const drawW = Math.max(40, (layout.relW ?? 0.2) * canvasExport.width);

      function finish(){
        canvasExport.toBlob((blob) => {
          if(blob) resolve(blob);
          else reject(new Error("Layout konnte nicht erstellt werden."));
        }, "image/jpeg", 0.86);
      }

      if(layout.mode === "logo" && layout.logoSrc){
        const designImage = new Image();
        designImage.onload = function(){
          const ratio = designImage.naturalHeight && designImage.naturalWidth ? designImage.naturalHeight / designImage.naturalWidth : 1;
          ctx.drawImage(designImage, drawX, drawY, drawW, drawW * ratio);
          finish();
        };
        designImage.onerror = function(){ finish(); };
        designImage.src = layout.logoSrc;
      } else {
        const fontSize = Math.max(20, (layout.fontSizePx || 28) / 560 * canvasExport.height);
        ctx.fillStyle = layout.color || "#000000";
        ctx.font = "900 " + fontSize + "px " + (layout.fontValue || "Arial, sans-serif");
        ctx.textBaseline = "top";
        ctx.fillText(layout.text || "Dein Text", drawX, drawY);
        finish();
      }
    };

    productImage.onerror = function(){
      reject(new Error("Produktbild konnte nicht geladen werden."));
    };

    productImage.src = item.productImg;
  });
}

function downloadAllRequestDesignImages(){
  if(!requestItems.length){
    const addNow = confirm("Es wurde noch kein Produkt/Layout zur Anfrage hinzugefügt. Soll das aktuell sichtbare Layout jetzt hinzugefügt und heruntergeladen werden?");
    if(addNow){
      addCurrentProductToRequest();
    } else {
      return;
    }
  }

  alert("Es werden jetzt " + requestItems.length + " Layout-Datei(en) heruntergeladen. Bitte diese PNG-Dateien danach manuell an die E-Mail anhängen.");

  requestItems.forEach((item, index) => {
    setTimeout(() => {
      exportLayoutItemAsPng(item, index);
    }, index * 700);
  });
}

function exportLayoutItemAsPng(item, index){
  const canvasExport = document.createElement("canvas");
  const ctx = canvasExport.getContext("2d");
  const productImage = new Image();

  productImage.onload = function(){
    canvasExport.width = productImage.naturalWidth || 1200;
    canvasExport.height = productImage.naturalHeight || 900;

    ctx.fillStyle = "#ffffff";
    ctx.fillRect(0, 0, canvasExport.width, canvasExport.height);
    ctx.drawImage(productImage, 0, 0, canvasExport.width, canvasExport.height);

    const layout = item.layout || {};
    const drawX = (layout.relX ?? 0.3) * canvasExport.width;
    const drawY = (layout.relY ?? 0.3) * canvasExport.height;
    const drawW = Math.max(40, (layout.relW ?? 0.2) * canvasExport.width);

    if(layout.mode === "logo" && layout.logoSrc){
      const designImage = new Image();
      designImage.onload = function(){
        const ratio = designImage.naturalHeight && designImage.naturalWidth ? designImage.naturalHeight / designImage.naturalWidth : 1;
        ctx.drawImage(designImage, drawX, drawY, drawW, drawW * ratio);
        triggerPngDownload(canvasExport, "layout-" + (index + 1) + "-" + slugify(item.title) + ".png");
      };
      designImage.src = layout.logoSrc;
    } else {
      const fontSize = Math.max(20, (layout.fontSizePx || 28) / 560 * canvasExport.height);
      ctx.fillStyle = layout.color || "#000000";
      ctx.font = "900 " + fontSize + "px " + (layout.fontValue || "Arial, sans-serif");
      ctx.textBaseline = "top";
      ctx.fillText(layout.text || "Dein Text", drawX, drawY);
      triggerPngDownload(canvasExport, "layout-" + (index + 1) + "-" + slugify(item.title) + ".png");
    }
  };

  productImage.src = item.productImg;
}

function triggerPngDownload(canvasExport, filename){
  const a = document.createElement("a");
  a.href = canvasExport.toDataURL("image/png");
  a.download = filename || "design-anfrage.png";
  document.body.appendChild(a);
  a.click();
  a.remove();
}

function slugify(text){
  return String(text || "produkt")
    .toLowerCase()
    .replace(/[ä]/g, "ae")
    .replace(/[ö]/g, "oe")
    .replace(/[ü]/g, "ue")
    .replace(/[ß]/g, "ss")
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "")
    .slice(0, 40) || "produkt";
}

async function sendOrder(){
  const prod = products[currentProductIndex];
  const clientEmail = document.getElementById("client-email").value.trim();
  const status = document.getElementById("send-status");

  if(!prod){ alert("Bitte Produkt auswählen."); return; }
  if(!clientEmail){ alert("Bitte gib deine E-Mail-Adresse an."); return; }

  if(!requestItems.length){
    const addNow = confirm("Es wurde noch kein Produkt/Layout zur Anfrage hinzugefügt. Soll das aktuell sichtbare Layout jetzt hinzugefügt werden?");
    if(addNow){
      addCurrentProductToRequest();
    } else {
      return;
    }
  }

  const mailText = buildMailText();
  const copyText = document.getElementById("mail-copy-text");
  const fallback = document.getElementById("mail-fallback");
  if(fallback && copyText){
    fallback.style.display = "block";
    copyText.value = mailText;
  }

  const sendBtn = document.getElementById("send-order-btn");
  sendBtn.disabled = true;
  sendBtn.textContent = "Wird gesendet...";
  status.textContent = "Layouts werden vorbereitet und Anfrage wird gesendet...";

  try {
    const formData = new FormData();
    formData.append("form-name", "design-anfrage");
    formData.append("kunde_email", clientEmail);
    formData.append("nachricht", mailText);

    const maxFiles = Math.min(requestItems.length, 5);
    for(let i = 0; i < maxFiles; i++){
      const blob = await createLayoutBlob(requestItems[i]);
      formData.append("layout_" + (i + 1), blob, "layout-" + (i + 1) + "-" + slugify(requestItems[i].title) + ".jpg");
    }

    const response = await fetch("/", {
      method: "POST",
      body: formData
    });

    if(!response.ok){
      throw new Error("Formular konnte nicht gesendet werden.");
    }

    status.textContent = "Danke! Die Anfrage wurde erfolgreich gesendet.";
    alert("Anfrage wurde erfolgreich gesendet.");
  } catch(error) {
    status.textContent = "Direktversand fehlgeschlagen. Bitte prüfen, ob die Seite online auf Netlify liegt.";
    alert("Direktversand fehlgeschlagen. Wenn du die Datei lokal am PC öffnest, funktioniert das noch nicht. Lade die Seite zuerst auf Netlify hoch.");
  } finally {
    sendBtn.disabled = false;
    sendBtn.textContent = "Anfrage direkt senden";
  }
}

document.addEventListener("click", function(e){
  if(e.target && e.target.id === "copy-mail-btn"){
    const copyText = document.getElementById("mail-copy-text");
    if(!copyText) return;
    copyText.select();
    copyText.setSelectionRange(0, 99999);
    navigator.clipboard?.writeText(copyText.value).then(function(){
      alert("E-Mail-Text wurde kopiert.");
    }).catch(function(){
      document.execCommand("copy");
      alert("E-Mail-Text wurde kopiert.");
    });
  }
});

function formatPrice(value){
  const n = Number(String(value).replace(",", "."));
  return Number.isFinite(n) ? n.toFixed(2) : "0.00";
}
</script>
</body>
</html>`;
}
