PROTEX Projekt v7 - Netlify Forms

Diese Version ist für Online-Verwendung auf Netlify gedacht.

Was neu ist:
- Anfrage wird direkt über Netlify Forms gesendet.
- Layoutbilder werden automatisch erzeugt und als Dateien mitgesendet.
- Kein EmailJS-Key nötig.
- Kein eigener Server nötig.
- Bis zu 5 Layoutbilder pro Anfrage sind vorbereitet.

Wichtig:
1. ZIP entpacken.
2. admin.html öffnen.
3. Produkte/Firmenlogo anlegen.
4. Kunden-Konfigurator exportieren.
5. Die exportierte kunden_konfigurator.html auf Netlify hochladen.
6. Erst online funktioniert der direkte Versand.

Hinweis:
Netlify Forms erkennt Formulare beim Deployment. Deshalb muss die finale kunden_konfigurator.html auf Netlify liegen.
Lokal am PC kann der Direktversand nicht funktionieren.
